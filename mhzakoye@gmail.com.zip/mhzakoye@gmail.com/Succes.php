
<!DOCTYPE html>
<html>
<head>
	<title>Université MHZ</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css\Succes.css"/>
		<!--ceci pour enlever le soulignement des liens-->
	<style type="text/css">A{text-decoration: none;} </style>
</head>
<body>
<!--ceci pour le menu de navigation-->
	<nav class="menu-nav">
	<img src="image/logo.png">
		<ul>
			<li class="boutton">
				<a href="Acceuil.php">Acceuil</a>
			</li>
			<li class="boutton">
				<a href="Inscription.php">Inscription</a>
			</li>
			<li class="boutton">
				<a href="Succes.php">Succes</a>
			</li>
		</ul>
	</nav>

	<header>
		<div class="devise1">
		<div class="devise2">
		<h1>vous êtes inscrit l'Université MHZ</h1>
		 <!--fonction php qui permet lier base mysql et le site-->

		<p class="subtitle">  
			<?php
                             var_dump($_POST);
                             $db=null;
                             $insertion=null;
               try {
  	                  $db =new PDO('mysql:host=localhost:3308;dbname=mabase', 'root','');
  	
                   } catch (PDOException $e) {
  	                     die('Erreur' .$e->getMessage());
                   }

                     if(isset($_POST['submit']))
                      {
                      	
                     
                     
   }

             ?>
                        	
        </p>
	    </div>
        </div>

	</header>
	<footer> copyright commit school 1.0 2019</footer>

</body>

</html>