<!DOCTYPE html>
<html>
<head>
	<title>Université MHZ</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css\Acceuil.css"/>
		<!--ceci pour enlever le soulignement des liens-->
	<style type="text/css">A{text-decoration: none;} </style>
</head>
<body>
<!--ceci pour le menu de navigation-->
	<nav class="menu-nav">
	<img src="image/logo.png">
		<ul>
			<li class="boutton">
				<a href="Acceuil.php">Acceuil</a>
			</li>
			<li class="boutton">
				<a href="Inscription.php">Inscription</a>
			</li>
			<li class="boutton">
				<a href="Succes.php">Succes</a>
			</li>
		</ul>
	</nav>

	<header>
		<div class="devise1">
		<div class="devise2">
		<h1>Bienvenue à l'Université MHZ</h1>
		<p class="subtitle"> La meilleur Université d'Afrique</p>
<!--ceci pour le menu de navigation-->
		<div class="slider-wrapper">
		  <div class="slider">
		     <div class="slider-text1"> Apprendre à coder </div>
		     <div class="slider-text2"> Apprendre l'architecture</div>
		     <div class="slider-text3"> Apprendre la comptabilité</div>
		   </div>
        </div>

	    </div>
        </div>
	</header>
	<footer> copyright commit school 1.0 2019</footer>

</body>

</html>