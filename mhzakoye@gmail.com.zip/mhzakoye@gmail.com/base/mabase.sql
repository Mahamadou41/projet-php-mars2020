-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3308
-- Généré le :  mer. 01 avr. 2020 à 10:24
-- Version du serveur :  8.0.18
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `mabase`
--

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `pseudo` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Telephone` int(8) NOT NULL,
  `genre` varchar(5) NOT NULL,
  `pays` varchar(30) NOT NULL,
  `type formation` varchar(30) NOT NULL,
  `cursus` varchar(30) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `parent` varchar(8) NOT NULL,
  PRIMARY KEY (`pseudo`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `pseudo` (`pseudo`),
  UNIQUE KEY `Telephone` (`Telephone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`pseudo`, `Email`, `Telephone`, `genre`, `pays`, `type formation`, `cursus`, `photo`, `parent`) VALUES
('Mahamadou', 'mhzakoye', 90119607, 'H', 'Niger', 'Initiale', 'programation', '', '90119607');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
