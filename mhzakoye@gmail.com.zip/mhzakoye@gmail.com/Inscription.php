<!DOCTYPE html>
<html>
<head>
	<title>Université MHZ</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css\Inscription.css"/>
		<!--ceci pour enlever le soulignement des liens-->
	<style type="text/css">A{text-decoration: none;} </style>
</head>
<body>
<!--ceci pour le menu de navigation-->
	<nav class="menu-nav">
	<img src="image/logo.png">
		<ul>
			<li class="boutton">
				<a href="Acceuil.php">Acceuil</a>
			</li>
			<li class="boutton">
				<a href="Inscription.php">Inscription</a>
			</li>
			<li class="boutton">
				<a href="Succes.php">Succes</a>
			</li>
		</ul>
	</nav>

	<header>
		<div class="devise1">
		<div class="devise2">
		<h1> veuillez remplir le formulaire ci-dessous</h1>
<!--ceci pour le formulaire-->
    <form action="Succes.php" method="POST" enctype="multipart/form-data">
	<p>
		<fieldset>
			<legend> Information Etudiant</legend>
		<label for="pseudo">
			Nom et Prénom:
		</label>
			<input type="text" name="pseudo" id="pseudo" minlength="3">
			<br/><br/>
		<label for="Email">
			Adresse Email:
		</label>
			<input type="email" name="Email" id="Email">	
		    <br/><br/>
		<label for="Telephone">
			Telephone:
		</label>
			<input type="tel" name="Telephone" id="Telephone">
		    <br/><br/>
		    Cochez votre genre:
		    <input type="radio" name="genre" value="Femme" id="Femme"/>
		    <label for="Femme">Femme</label>
		    <input type="radio" name="genre" value="Homme" id="Homme"/>
		    <label for="Homme">Homme</label>
		    <br/><br/>
		    Choisissez votre pays:
		    <select name="pays" id="pays">
		    	<option value="Niger">Niger</option>
		    	<option value="Nigeria">Nigeria</option>
		    	<option value="Mali">Mali</option>
		    	<option value="Côte d'ivoire">Côte d'ivoire</option>
		        <option value="Autre">Autre</option>
		    </select>
		    <br/><br/>
		     Type formation:
		    <input type="radio" name="type formation" value="Initiale" id="Initiale">
		    <label for="Initiale">Initiale</label>
		    <input type="radio" name="type formation" value="Continue" id="Continue"/>
		    <label for="Continue">Continue</label>
		    <br/><br/>
		    Choisir cursus:
		    <select name="cursus" id="cursus">
		    	<option value="Programmation">Programmation</option>
		    	<option value="Comptabilité">Comptabilité</option>
		    	<option value="Statistique">Statistique</option>
		    	<option value="Infographie">Infograhie</option>
		    </select>
		    <br/><br/>
            <label for="photo">
			Insert une photo:
		    </label>
			<input type="file" name="photo" id="photo">
		    <br/><br/>
		    <label for="parent">
			Telephone Parent:
		</label>
			<input type="tel" name="parent" id="parent">
		    <br/><br/>
		    <label for="commentaire">
		    Pourquoi vous avez choisis MHZ?
		</label>
		<textarea type="commentaire" name="commentaire" id="commentaire"></textarea>
			</fieldset>
			
		<input type="submit"  name="VALIDER" id="VALIDER"value="VALIDER">

	    </div>
        </div>
    </p>
    </form>
<!--script de controle du formualire-->

	</header>
	<footer> copyright commit school 1.0 2019</footer>

</body>

</html>